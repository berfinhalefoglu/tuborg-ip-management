# printer.py
from reportlab.lib.pagesizes import landscape, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors

def create_pdf(data, filename="veritabani_ciktisi.pdf"):
    doc = SimpleDocTemplate(filename, pagesize=landscape(A4))
    elements = []
    # Sütun genişliklerini başlıklara göre ayarla (örnek değerler!)
    col_widths = [
        60,   # Main Line
        100,  # Line Details
        60,   # Inside VLAN ID
        70,   # Inside IP Subnet
        80,   # Inside Subnet Mask
        80,   # Inside IP Gateway
        70,   # Outside VLAN ID
        80,   # Outside IP Subnet
        70,   # Outside Subnet Bit
        90,   # Outside Subnet Mask
        80,   # Outside IP Gateway
    ]
    table = Table(data, colWidths=col_widths)
    table.setStyle(TableStyle([
        ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('BACKGROUND', (0,0), (-1,0), colors.lightgrey),
        ('GRID', (0,0), (-1,-1), 0.5, colors.black),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2),
        ('TOPPADDING', (0,0), (-1,-1), 2),
        ('LEFTPADDING', (0,0), (-1,-1), 2),
        ('RIGHTPADDING', (0,0), (-1,-1), 2),
    ]))
    elements.append(table)
    doc.build(elements)
